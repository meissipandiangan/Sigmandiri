<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PhpOffice\PhpWord\TemplateProcessor;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class GugatanController extends Controller
{
    /**
     * Halaman home/beranda
     */
    public function home()
    {
        return view('home');
    }

    /**
     * Halaman pilih jenis gugatan
     */
    public function index()
    {
        return view('gugatan.index');
    }

    public function create($jenis)
    {
        if (!in_array($jenis, ['perorangan', 'kuasa_hukum'])) {
            abort(404);
        }
        
        return view('gugatan.create', compact('jenis'));
    }

    public function store(Request $request)
    {
        \Log::info('=== GUGATAN STORE START ===');
        
        $rules = [
            'jenis' => 'required|in:perorangan,kuasa_hukum',
            'nama_penggugat' => 'required|string',
            'kewarganegaraan_penggugat' => 'required|string',
            'tempat_tinggal_penggugat' => 'required|string',
            'pekerjaan_penggugat' => 'required|string',
            'email_penggugat' => 'required|email',
            'nama_tergugat' => 'required|string',
            'alamat_tergugat' => 'required|string',
            'judul_keputusan' => 'required|string',
            'nomor_keputusan' => 'required|string',
            'tanggal_keputusan' => 'required|date',
            'perihal_keputusan' => 'required|string',
            'sengketa_quo_individual' => 'required|string',
            'sengketa_quo_final' => 'required|string',
            'siapa_penggugat' => 'required|string',
            'gugatan_dasar' => 'required|string',
            'hubungan_hukum_objek_sengketa' => 'required|string',
            'kepentingan_nyata_penggugat' => 'required|string',
            'tanggal_penerbitan_objek' => 'required|date',
            'tanggal_objek_diterima' => 'required|date',
            'upaya_administratif_yg_telah_ditempuh' => 'required|string',
            'tanggal_pengajuan_gugatan' => 'required|date',
            'uraian_substansi_sengketa_dan_alasan_gugatan' => 'required|string',
            'uraian_tindakan_tergugat_yang_bertentangan_dengan_uu' => 'required|string',
            'uraian_tindakan_tergugat_yang_bertentangan_dengan_aupb' => 'required|string',
            'petitum_2_keterangan' => 'required|string',
            'petitum_3_keterangan' => 'required|string',
        ];

        if ($request->jenis == 'kuasa_hukum') {
            $rules['nama_kuasa_hukum'] = 'required|string';
            $rules['kantor_kuasa_hukum'] = 'required|string';
            $rules['alamat_kantor_hukum'] = 'required|string';
            $rules['email_kuasa_hukum'] = 'required|email';
            $rules['telepon_kuasa_hukum'] = 'required|string';
            $rules['nomor_surat_kuasa'] = 'required|string';
            $rules['tanggal_surat_kuasa'] = 'required|date';
            $rules['penetapan_tertulis_pejabat_tun'] = 'required|string';
        }

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            \Log::warning('Validation failed', ['errors' => $validator->errors()]);
            
            return response()->json([
                'success' => false,
                'message' => 'Validasi gagal',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            \Log::info('Starting document generation...');
            
            // Generate dokumen
            $fileName = $this->generateDocument($request->all());
            
            \Log::info('Document generated: ' . $fileName);
            
            // Return JSON dengan download URL
            return response()->json([
                'success' => true,
                'message' => 'Dokumen berhasil dibuat!',
                'data' => [
                    'download_url' => url('/gugatan/download/' . $fileName),
                    'file_name' => $fileName
                ]
            ], 200);

        } catch (\Exception $e) {
            \Log::error('=== ERROR ===');
            \Log::error('Message: ' . $e->getMessage());
            \Log::error('File: ' . $e->getFile() . ':' . $e->getLine());

            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan: ' . $e->getMessage()
            ], 500);
        }
    }

    private function generateDocument(array $data)
    {
        $templateName = $data['jenis'] == 'kuasa_hukum' 
            ? 'gugatan_kuasa_hukum.docx' 
            : 'gugatan_perorangan.docx';
        
        $templatePath = storage_path('app/templates/' . $templateName);

        if (!file_exists($templatePath)) {
            throw new \Exception("Template tidak ditemukan: {$templateName}. Path: {$templatePath}");
        }

        $templateProcessor = new TemplateProcessor($templatePath);

        // Replace semua placeholder
        $templateProcessor->setValue('tanggal', now()->locale('id')->isoFormat('D MMMM YYYY'));
        $templateProcessor->setValue('nama_penggugat', $data['nama_penggugat']);
        $templateProcessor->setValue('kewarganegaraan_penggugat', $data['kewarganegaraan_penggugat']);
        $templateProcessor->setValue('tempat_tinggal_penggugat', $data['tempat_tinggal_penggugat']);
        $templateProcessor->setValue('pekerjaan_penggugat', $data['pekerjaan_penggugat'] ?? '-');
        $templateProcessor->setValue('email_penggugat', $data['email_penggugat']);

        if ($data['jenis'] == 'kuasa_hukum') {
            $templateProcessor->setValue('nama_kuasa_hukum', $data['nama_kuasa_hukum']);
            $templateProcessor->setValue('kantor_kuasa_hukum', $data['kantor_kuasa_hukum']);
            $templateProcessor->setValue('alamat_kantor_hukum', $data['alamat_kantor_hukum']);
            $templateProcessor->setValue('email_kuasa_hukum', $data['email_kuasa_hukum']);
            $templateProcessor->setValue('telepon_kuasa_hukum', $data['telepon_kuasa_hukum']);
            $templateProcessor->setValue('nomor_surat_kuasa', $data['nomor_surat_kuasa'] ?? '-');
            $templateProcessor->setValue('tanggal_surat_kuasa', 
                \Carbon\Carbon::parse($data['tanggal_surat_kuasa'])->locale('id')->isoFormat('D MMMM YYYY'));
            $templateProcessor->setValue('penetapan_tertulis_pejabat_tun', $data['penetapan_tertulis_pejabat_tun']);
        }

        $templateProcessor->setValue('nama_tergugat', $data['nama_tergugat']);
        $templateProcessor->setValue('alamat_tergugat', $data['alamat_tergugat']);
        $templateProcessor->setValue('email_tergugat', $data['email_tergugat'] ?? '-');
        $templateProcessor->setValue('judul_keputusan', $data['judul_keputusan']);
        $templateProcessor->setValue('nomor_keputusan', $data['nomor_keputusan']);
        $templateProcessor->setValue('tanggal_keputusan', 
            \Carbon\Carbon::parse($data['tanggal_keputusan'])->locale('id')->isoFormat('D MMMM YYYY'));
        $templateProcessor->setValue('perihal_keputusan', $data['perihal_keputusan']);
        $templateProcessor->setValue('nama_yang_dituju', $data['nama_yang_dituju'] ?? '-');
        $templateProcessor->setValue('sengketa_quo_individual', $data['sengketa_quo_individual']);
        $templateProcessor->setValue('sengketa_quo_final', $data['sengketa_quo_final']);
        $templateProcessor->setValue('siapa_penggugat', $data['siapa_penggugat']);
        $templateProcessor->setValue('gugatan_dasar', $data['gugatan_dasar']);
        $templateProcessor->setValue('hubungan_hukum_objek_sengketa', $data['hubungan_hukum_objek_sengketa']);
        $templateProcessor->setValue('kepentingan_nyata_penggugat', $data['kepentingan_nyata_penggugat']);
        $templateProcessor->setValue('tanggal_penerbitan_objek', 
            \Carbon\Carbon::parse($data['tanggal_penerbitan_objek'])->locale('id')->isoFormat('D MMMM YYYY'));
        $templateProcessor->setValue('tanggal_objek_diterima', 
            \Carbon\Carbon::parse($data['tanggal_objek_diterima'])->locale('id')->isoFormat('D MMMM YYYY'));
        $templateProcessor->setValue('upaya_administratif_yg_telah_ditempuh', $data['upaya_administratif_yg_telah_ditempuh']);
        $templateProcessor->setValue('tanggal_pengajuan_gugatan', 
            \Carbon\Carbon::parse($data['tanggal_pengajuan_gugatan'])->locale('id')->isoFormat('D MMMM YYYY'));
        $templateProcessor->setValue('uraian_substansi_sengketa_dan_alasan_gugatan', $data['uraian_substansi_sengketa_dan_alasan_gugatan']);
        $templateProcessor->setValue('uraian_tindakan_tergugat_yang_bertentangan_dengan_uu', $data['uraian_tindakan_tergugat_yang_bertentangan_dengan_uu']);
        $templateProcessor->setValue('uraian_tindakan_tergugat_yang_bertentangan_dengan_aupb', $data['uraian_tindakan_tergugat_yang_bertentangan_dengan_aupb']);
        $templateProcessor->setValue('petitum_2_keterangan', $data['petitum_2_keterangan']);
        $templateProcessor->setValue('petitum_3_keterangan', $data['petitum_3_keterangan']);
        $templateProcessor->setValue('petitum_tambahan', $data['petitum_tambahan'] ?? '');

        // Generate unique filename
        $fileName = 'Gugatan_' . str_replace(' ', '_', $data['nama_penggugat']) . '_' . time() . '.docx';
        $outputPath = storage_path('app/public/documents/' . $fileName);
        
        if (!file_exists(dirname($outputPath))) {
            mkdir(dirname($outputPath), 0755, true);
        }

        $templateProcessor->saveAs($outputPath);

        return $fileName;
    }

    public function downloadDirect($file)
    {
        \Log::info('Download request for: ' . $file);
        
        $filePath = storage_path('app/public/documents/' . $file);
        
        if (!file_exists($filePath)) {
            \Log::error('File not found: ' . $filePath);
            abort(404, 'File tidak ditemukan');
        }

        return response()->download($filePath, $file, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ])->deleteFileAfterSend(true);
    }
}